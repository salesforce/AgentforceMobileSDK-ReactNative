//
//  SMICitedReferenceType.h
//  SMIClientCore
//
//  Created by Nigel Brown on 2025-03-11.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString *SMICitedReferenceType NS_TYPED_ENUM
NS_SWIFT_NAME(CitedReferenceType);

FOUNDATION_EXPORT SMICitedReferenceType const SMICitedReferenceTypeLink;

NS_ASSUME_NONNULL_END
