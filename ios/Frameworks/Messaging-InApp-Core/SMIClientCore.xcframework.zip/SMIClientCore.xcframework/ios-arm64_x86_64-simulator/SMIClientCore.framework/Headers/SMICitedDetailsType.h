//
//  SMICitedDetailsType.h
//  SMIClientCore
//
//  Created by Nigel Brown on 2025-03-11.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NSString *SMICitedDetailsType NS_TYPED_ENUM
NS_SWIFT_NAME(CitedDetailsType);

FOUNDATION_EXPORT SMICitedDetailsType const SMICitedDetailsTypeInlineMetadata;

NS_ASSUME_NONNULL_END
