//
//  SMIParticipantv170tov180.h
//  SMIClientCore
//
//  Created by Aaron Eisses on 2024-11-15.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface SMIParticipantv170tov180 : NSEntityMigrationPolicy

@end

NS_ASSUME_NONNULL_END
